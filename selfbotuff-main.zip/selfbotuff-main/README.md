# Discord TikTok Selfbot

A Discord selfbot that fetches random TikTok videos and sends them directly in chat.

## Features

- Fetch random TikTok videos using free API
- Send videos directly as Discord attachments (not links)
- Display video author, description, and like count
- Automatic file size validation
- Simple `fyp` command to trigger

## Prerequisites

- Node.js 16.9.0 or higher
- A Discord account
- Discord token (from Developer Portal)

## Installation

1. Clone the repository:
```bash
git clone <repo-url>
cd discord-tiktok-selfbot
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file:
```bash
cp .env.example .env
```

4. Add your Discord token to `.env`:
```
DISCORD_TOKEN=your_token_here
```

## Getting Your Discord Token

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application
3. Go to "Bot" section and click "Add Bot"
4. Copy the token and paste it in `.env`

## Usage

1. Start the bot:
```bash
npm start
```

2. In any Discord channel or DM, type:
```
fyp
```

The bot will fetch a random TikTok video and send it as a video file in the chat.

## How It Works

- Uses the free TikTok API endpoint from `tikmate.online`
- Downloads the video as a buffer
- Validates file size (Discord 25MB limit for regular users)
- Sends the video as a Discord attachment with metadata

## Important Notes

- This is a **selfbot** - it only responds to your own messages
- Respect Discord's Terms of Service
- The free API may have rate limits
- Videos larger than 25MB will be rejected
- Ensure you have permission to use TikTok content

## Troubleshooting

**Bot not responding:**
- Check that your Discord token is correct in `.env`
- Ensure the bot is running (`npm start`)
- Verify you're typing `fyp` in a channel the bot can see

**Video download fails:**
- The TikTok API might be rate-limited
- Try again in a few moments
- Check your internet connection

**Video too large:**
- Some TikTok videos exceed Discord's 25MB limit
- Try the `fyp` command again for a different video

## License

MIT
