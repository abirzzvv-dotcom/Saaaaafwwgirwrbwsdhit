# Deployment Guide

This Discord selfbot can be deployed on various platforms. Follow the instructions below for your preferred service.

## Prerequisites

- Node.js 18+ (if running locally)
- A Discord bot token in `.env` file

## Local Setup

```bash
# Install dependencies
npm install

# Create .env file with your Discord token
echo "DISCORD_TOKEN=your_token_here" > .env

# Run the bot
npm start

# Or with auto-reload (development)
npm run dev
```

## Docker Deployment

### Build and Run Locally

```bash
# Build the Docker image
docker build -t discord-tiktok-bot .

# Run the container
docker run -e DISCORD_TOKEN=your_token_here discord-tiktok-bot
```

### Deploy to Docker Hub

```bash
# Tag the image
docker tag discord-tiktok-bot your-username/discord-tiktok-bot:latest

# Push to Docker Hub
docker push your-username/discord-tiktok-bot:latest
```

## Heroku Deployment

1. Install Heroku CLI
2. Login: `heroku login`
3. Create app: `heroku create your-app-name`
4. Set environment variable: `heroku config:set DISCORD_TOKEN=your_token_here`
5. Deploy: `git push heroku main`

## Railway Deployment

1. Go to [railway.app](https://railway.app)
2. Create new project
3. Connect your GitLab repository
4. Add environment variable `DISCORD_TOKEN`
5. Deploy automatically

## Replit Deployment

1. Go to [replit.com](https://replit.com)
2. Import from Git: paste your GitLab repo URL
3. Create `.env` file with `DISCORD_TOKEN=your_token_here`
4. Click "Run" to start the bot

## Environment Variables

- `DISCORD_TOKEN` - Your Discord bot token (required)

## Troubleshooting

- **Bot not responding**: Check that the token is valid and the bot has message permissions
- **Video download fails**: The TikTok API may be rate-limited; wait a few minutes
- **File size errors**: Videos larger than 25MB cannot be sent (100MB with Nitro)
