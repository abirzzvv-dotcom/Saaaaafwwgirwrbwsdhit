const { Client } = require('discord.js-selfbot-v13');
const axios = require('axios');
require('dotenv').config();
const config = require('./config.json');

const client = new Client();

// ─── Snipe Storage ───────────────────────────────────────────────────────────
// Store deleted and edited messages per user
const deletedMessages = new Map();
const editedMessages = new Map();

const MAX_SNIPE_STORAGE = 100;

// URL regex to extract links from message content
const URL_REGEX = /https?:\/\/[^\s<>"']+/gi;

function extractUrls(text) {
  if (!text) return [];
  const matches = text.match(URL_REGEX);
  return matches ? [...new Set(matches)] : [];
}

function getAttachmentType(attachment) {
  const contentType = attachment.contentType || '';
  const name = attachment.name || '';
  
  if (contentType.startsWith('image/') || /\.(png|jpg|jpeg|gif|webp|bmp)$/i.test(name)) {
    return 'image';
  } else if (contentType.startsWith('video/') || /\.(mp4|webm|mov|avi|mkv)$/i.test(name)) {
    return 'video';
  } else if (contentType.startsWith('audio/') || /\.(mp3|wav|ogg|flac)$/i.test(name)) {
    return 'audio';
  }
  return 'file';
}

function formatAttachment(att) {
  const icons = {
    image: '🖼️',
    video: '🎬',
    audio: '🎵',
    file: '📎'
  };
  return {
    name: att.name || 'unknown',
    url: att.url || att.proxyURL,
    type: getAttachmentType(att),
    icon: icons[getAttachmentType(att)],
    size: att.size || 0
  };
}

function addDeletedMessage(userId, messageData) {
  if (!deletedMessages.has(userId)) {
    deletedMessages.set(userId, []);
  }
  const userMessages = deletedMessages.get(userId);
  userMessages.unshift(messageData);
  if (userMessages.length > MAX_SNIPE_STORAGE) {
    userMessages.pop();
  }
}

function addEditedMessage(userId, messageData) {
  if (!editedMessages.has(userId)) {
    editedMessages.set(userId, []);
  }
  const userMessages = editedMessages.get(userId);
  userMessages.unshift(messageData);
  if (userMessages.length > MAX_SNIPE_STORAGE) {
    userMessages.pop();
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function normaliseUrl(input) {
  return /^https?:\/\//i.test(input) ? input : 'https://' + input;
}

function formatTimestamp(date) {
  return `<t:${Math.floor(date.getTime() / 1000)}:R>`;
}

function extractUserId(mention) {
  const match = mention.match(/^<@!?(\d+)>$/) || mention.match(/^(\d+)$/);
  return match ? match[1] : null;
}

function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

// ─── TikTok helpers ──────────────────────────────────────────────────────────

async function fetchRandomTikTok() {
  try {
    const response = await axios.get('https://www.tikwm.com/api/feed/list', {
      params: { count: 20, cursor: 0, web: 1, hd: 1 },
      headers: { 'User-Agent': config.view.userAgent },
      timeout: 15000,
    });
    const data = response.data;
    if (data?.code === 0 && data.data?.videos?.length > 0) {
      const video = data.data.videos[Math.floor(Math.random() * data.data.videos.length)];
      return {
        url: `https://www.tikwm.com${video.play}`,
        author: video.author?.nickname || video.author?.unique_id || 'Unknown',
        description: video.title || 'No description',
        likes: video.digg_count || 0,
      };
    }
    return null;
  } catch (err) {
    console.error('TikTok fetch error:', err.message);
    return null;
  }
}

async function downloadVideo(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': config.view.userAgent, Referer: 'https://www.tikwm.com/' },
      timeout: 30000,
    });
    return Buffer.from(response.data);
  } catch (err) {
    console.error('Video download error:', err.message);
    return null;
  }
}

// ─── Bot events ──────────────────────────────────────────────────────────────

client.on('ready', () => {
  console.log(`✓ Logged in as ${client.user.tag}`);
});

// Track deleted messages
client.on('messageDelete', (message) => {
  if (!message.author || message.author.bot) return;
  
  const content = message.content || '';
  const attachments = message.attachments.map(att => formatAttachment(att));
  const embeds = message.embeds || [];
  const urls = extractUrls(content);
  
  // Also extract image URLs from embeds
  const embedImages = embeds
    .filter(e => e.image || e.thumbnail)
    .map(e => ({
      name: 'embed_image',
      url: e.image?.url || e.thumbnail?.url,
      type: 'image',
      icon: '🖼️',
      size: 0
    }));
  
  const allAttachments = [...attachments, ...embedImages];
  
  // Skip if no content, attachments, or URLs
  if (!content && allAttachments.length === 0 && urls.length === 0) return;
  
  addDeletedMessage(message.author.id, {
    content: content,
    attachments: allAttachments,
    urls: urls,
    timestamp: new Date(),
    channelId: message.channel.id,
    channelName: message.channel.name || 'DM',
  });
});

// Track edited messages
client.on('messageUpdate', (oldMessage, newMessage) => {
  if (!oldMessage.author || oldMessage.author.bot) return;
  if (oldMessage.content === newMessage.content && 
      oldMessage.attachments.size === newMessage.attachments.size) return;
  
  const oldAttachments = oldMessage.attachments.map(att => formatAttachment(att));
  const newAttachments = newMessage.attachments.map(att => formatAttachment(att));
  const oldUrls = extractUrls(oldMessage.content || '');
  const newUrls = extractUrls(newMessage.content || '');
  
  addEditedMessage(oldMessage.author.id, {
    oldContent: oldMessage.content || '',
    newContent: newMessage.content || '',
    oldAttachments: oldAttachments,
    newAttachments: newAttachments,
    oldUrls: oldUrls,
    newUrls: newUrls,
    timestamp: new Date(),
    channelId: oldMessage.channel.id,
    channelName: oldMessage.channel.name || 'DM',
  });
});

client.on('messageCreate', async (message) => {
  if (message.author.id !== client.user.id) return;
  const content = message.content.trim();

  // ── snipe <user> <del/ed> <count> ──────────────────────────────────────────
  if (content.toLowerCase().startsWith('snipe ')) {
    const args = content.slice(6).trim().split(/\s+/);
    
    if (args.length < 3) {
      await message.channel.send('u, dlt/sn, int');
      return;
    }
    
    const userId = extractUserId(args[0]);
    const type = args[1].toLowerCase();
    const count = parseInt(args[2], 10);
    
    if (!userId) {
      await message.channel.send('ment/id');
      return;
    }
    
    if (type !== 'del' && type !== 'ed') {
      await message.channel.send('del/ed');
      return;
    }
    
    if (isNaN(count) || count < 1 || count > 100) {
      await message.channel.send('100');
      return;
    }
    
    await message.delete().catch(() => {});
    
    if (type === 'del') {
      const messages = deletedMessages.get(userId) || [];
      if (messages.length === 0) {
        await message.channel.send(`empt`);
        return;
      }
      
      const toShow = messages.slice(0, count);
      const chunks = [];
      let currentChunk = `del from <@${userId}> (${toShow.length}/${messages.length} \n\n`;
      
      for (let i = 0; i < toShow.length; i++) {
        const msg = toShow[i];
        let entry = `**${i + 1}.** ${formatTimestamp(msg.timestamp)} in #${msg.channelName}\n`;
        
        // Add content if exists
        if (msg.content) {
          const truncated = msg.content.length > 300 ? msg.content.slice(0, 300) + '...' : msg.content;
          entry += `\`\`\`${truncated}\`\`\`\n`;
        }
        
        // Add attachments
        if (msg.attachments && msg.attachments.length > 0) {
          entry += `atchm\n`;
          for (const att of msg.attachments) {
            const sizeStr = att.size > 0 ? ` (${formatFileSize(att.size)})` : '';
            entry += `${att.icon} [${att.name}](${att.url})${sizeStr}\n`;
          }
        }
        
        // Add URLs found in content (excluding attachment URLs)
        const attachmentUrls = (msg.attachments || []).map(a => a.url);
        const contentUrls = (msg.urls || []).filter(u => !attachmentUrls.includes(u));
        if (contentUrls.length > 0) {
          entry += `url\n`;
          for (const url of contentUrls.slice(0, 5)) {
            const truncUrl = url.length > 60 ? url.slice(0, 60) + ',' : url;
            entry += `${truncUrl}\n`;
          }
          if (contentUrls.length > 5) {
            entry += `n ${contentUrls.length - 5} more\n`;
          }
        }
        
        entry += '\n';
        
        // Check if adding this entry exceeds limit
        if (currentChunk.length + entry.length > 1900) {
          chunks.push(currentChunk);
          currentChunk = entry;
        } else {
          currentChunk += entry;
        }
      }
      
      if (currentChunk) chunks.push(currentChunk);
      
      for (const chunk of chunks) {
        await message.channel.send(chunk);
        await new Promise(r => setTimeout(r, 300));
      }
      
    } else {
      // type === 'ed'
      const messages = editedMessages.get(userId) || [];
      if (messages.length === 0) {
        await message.channel.send(`empty ahhb`);
        return;
      }
      
      const toShow = messages.slice(0, count);
      const chunks = [];
      let currentChunk = `edit  <@${userId}>** (${toShow.length}/${messages.length})\n\n`;
      
      for (let i = 0; i < toShow.length; i++) {
        const msg = toShow[i];
        let entry = `${i + 1} ${formatTimestamp(msg.timestamp)} in her,e #${msg.channelName}\n`;
        
        // Content changes
        if (msg.oldContent || msg.newContent) {
          const oldTrunc = (msg.oldContent || '(empty)').length > 200 
            ? msg.oldContent.slice(0, 200) + ',' 
            : (msg.oldContent || '(empty)');
          const newTrunc = (msg.newContent || '(empty)').length > 200 
            ? msg.newContent.slice(0, 200) + '...' 
            : (msg.newContent || '(empty)');
          entry += `old \`\`\`${oldTrunc}\`\`\`\n`;
          entry += `after looksmaxxinh \`\`\`${newTrunc}\`\`\`\n`;
        }
        
        // Attachment changes
        const removedAtts = (msg.oldAttachments || []).filter(
          old => !(msg.newAttachments || []).some(n => n.url === old.url)
        );
        const addedAtts = (msg.newAttachments || []).filter(
          n => !(msg.oldAttachments || []).some(old => old.url === n.url)
        );
        
        if (removedAtts.length > 0) {
          entry += `rmv attcm\n`;
          for (const att of removedAtts) {
            entry += `${att.icon} [${att.name}](${att.url})\n`;
          }
        }
        
        if (addedAtts.length > 0) {
          entry += `atcm added n dhi\n`;
          for (const att of addedAtts) {
            entry += `${att.icon} [${att.name}](${att.url})\n`;
          }
        }
        
        // URL changes
        const removedUrls = (msg.oldUrls || []).filter(u => !(msg.newUrls || []).includes(u));
        const addedUrls = (msg.newUrls || []).filter(u => !(msg.oldUrls || []).includes(u));
        
        if (removedUrls.length > 0) {
          entry += `url rmv ${removedUrls.slice(0, 3).join(', ')}\n`;
        }
        if (addedUrls.length > 0) {
          entry += `add url) ${addedUrls.slice(0, 3).join(', ')}\n`;
        }
        
        entry += '\n';
        
        if (currentChunk.length + entry.length > 1900) {
          chunks.push(currentChunk);
          currentChunk = entry;
        } else {
          currentChunk += entry;
        }
      }
      
      if (currentChunk) chunks.push(currentChunk);
      
      for (const chunk of chunks) {
        await message.channel.send(chunk);
        await new Promise(r => setTimeout(r, 300));
      }
    }
    return;
  }

  // ── fyp ────────────────────────────────────────────────────────────────────
  if (content.toLowerCase() === 'fyp') {
    try {
      await message.delete().catch(() => {});
      const loadingMsg = await message.channel.send('🎵 Fetching a TikTok for you...');
      const videoData = await fetchRandomTikTok();
      if (!videoData) { await loadingMsg.edit('❌ Failed to fetch TikTok video. Try again!'); return; }
      const videoBuffer = await downloadVideo(videoData.url);
      if (!videoBuffer) { await loadingMsg.edit('❌ Failed to download video. Try again!'); return; }
      const maxSize = 25 * 1024 * 1024;
      if (videoBuffer.length > maxSize) {
        await loadingMsg.edit(`❌ Video too large (${(videoBuffer.length / 1024 / 1024).toFixed(2)}MB). Discord limit is 25MB.`);
        return;
      }
      await loadingMsg.delete().catch(() => {});
      await message.channel.send({
        content: `**${videoData.author}** — ${videoData.description}\n❤️ ${videoData.likes.toLocaleString()} likes`,
        files: [{ attachment: videoBuffer, name: 'tiktok.mp4' }],
      });
    } catch (err) {
      console.error('fyp error:', err);
    }
    return;
  }

  // ── ss <url> ───────────────────────────────────────────────────────────────
  if (content.toLowerCase().startsWith('ss ')) {
    const input = content.slice(3).trim();
    if (!input) {
      await message.channel.send('no');
      return;
    }

    const screenshotUrl =
      `https://api.screenshotmachine.com?key=${config.view.screenshotKey}` +
      `&url=${normaliseUrl(input)}` +
      `&device=${config.view.device}` +
      `&dimension=${config.view.dimension}` +
      `&cacheLimit=0`;

    await message.delete().catch(() => {});

    try {
      const response = await axios.get(screenshotUrl, {
        responseType: 'arraybuffer',
        timeout: 30000,
      });

      const contentType = response.headers['content-type'] || '';
      if (!contentType.startsWith('image/')) {
        await message.channel.send(`err\`${normaliseUrl(input)}\`.`);
        return;
      }

      await message.channel.send({
        content: `${normaliseUrl(input)}**`,
        files: [{ attachment: Buffer.from(response.data), name: 'screenshot.png' }],
      });
    } catch (err) {
      console.error('ss erro', err.message);
      await message.channel.send(`err ${err.message}`);
    }
    return;
  }

  // ── view <website> [file] ──────────────────────────────────────────────────
  if (content.toLowerCase().startsWith('view ')) {
    const args = content.slice(5).trim().split(/\s+/);
    if (!args[0]) { await message.channel.send('lord'); return; }

    let baseUrl = normaliseUrl(args[0]);
    if (args[1]) {
      const file = args[1].startsWith('/') ? args[1] : '/' + args[1];
      try { baseUrl = new URL(baseUrl).origin + file; }
      catch { baseUrl = baseUrl.replace(/\/$/, '') + file; }
    }

    await message.delete().catch(() => {});
    const loadingMsg = await message.channel.send(`workin\`${baseUrl}\`,`);

    let body, status;
    try {
      const response = await axios.get(baseUrl, {
        headers: {
          'User-Agent': config.view.userAgent,
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
        },
        timeout: 10000,
        responseType: 'text',
        validateStatus: () => true,
      });
      body = response.data;
      status = response.status;
    } catch (err) {
      await loadingMsg.edit(`err${err.message}`);
      return;
    }

    if (!body || !body.toString().trim()) {
      await loadingMsg.edit(`no content \`${baseUrl}\` (HTTP ${status}).`);
      return;
    }

    const source = body.toString();
    const ext = (args[1] || baseUrl).split('.').pop().toLowerCase();
    const langMap = {
      js: 'js', ts: 'ts', html: 'html', htm: 'html', css: 'css',
      json: 'json', xml: 'xml', php: 'php', py: 'python', rb: 'ruby',
      txt: '', md: 'md', sh: 'bash', yaml: 'yaml', yml: 'yaml', sql: 'sql',
    };
    const lang = langMap[ext] ?? 'html';
    const maxChunk = 1900 - lang.length - 8;

    const chunks = [];
    let remaining = source;
    while (remaining.length > 0) {
      if (remaining.length <= maxChunk) { chunks.push(remaining); break; }
      let splitAt = remaining.lastIndexOf('\n', maxChunk);
      if (splitAt <= 0) splitAt = maxChunk;
      chunks.push(remaining.slice(0, splitAt));
      remaining = remaining.slice(splitAt).replace(/^\n/, '');
    }

    await loadingMsg.delete().catch(() => {});
    const total = chunks.length;
    for (let i = 0; i < total; i++) {
      const header = i === 0
        ? (total > 1 ? `\`${baseUrl}\` part ${i + 1}/${total}\n` : `\`${baseUrl}\`\n`)
        : `part ${i + 1}/${total}\n`;
      await message.channel.send(header + '```' + lang + '\n' + chunks[i] + '\n```');
      if (i < total - 1) await new Promise(r => setTimeout(r, 300));
    }
    return;
  }
});

// ─── Quest System ─────────────────────────────────────────────────────────────

let cachedQuests = [];

async function fetchQuests() {
  try {
    const response = await axios.get('https://discord.com/api/v9/users/@me/quests', {
      headers: {
        'Authorization': process.env.DISCORD_TOKEN,
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    
    // Handle both array and object responses
    let questData = response.data;
    if (questData && !Array.isArray(questData)) {
      // If it's an object with quests property
      questData = questData.quests || [questData];
    }
    
    cachedQuests = questData || [];
    console.log('Fetched quests:', JSON.stringify(cachedQuests, null, 2));
    return cachedQuests;
  } catch (err) {
    console.error('Quest fetch error:', err.response?.data || err.message);
    return [];
  }
}

function getQuestInfo(quest) {
  // Handle different quest structures
  const config = quest.config || quest;
  const id = quest.id || quest.quest_id;
  
  // Get quest name from various possible locations
  const name = config.messages?.quest_name || 
               config.quest_bar_strings?.title ||
               quest.quest_title ||
               config.name ||
               'Unknown Quest';
  
  // Get application info
  const appName = config.application?.name || 
                  quest.target_application?.name ||
                  config.application_name ||
                  'Unknown App';
  
  const appId = config.application?.id ||
                config.application_id ||
                quest.target_application?.id;
  
  // Determine quest type and duration
  let questType = 'Activity';
  let duration = 0;
  
  if (config.stream_duration_requirement) {
    questType = 'Stream';
    duration = config.stream_duration_requirement.duration_seconds || 0;
  } else if (config.play_on_desktop) {
    questType = 'Desktop Game';
    duration = config.play_on_desktop.duration_seconds || 0;
  } else if (config.video_progress_requirement) {
    questType = 'Watch';
    duration = config.video_progress_requirement.duration_seconds || 0;
  } else if (config.stream_progress_requirement) {
    questType = 'Stream';
    duration = config.stream_progress_requirement.duration_seconds || 0;
  }
  
  // Check completion status
  const userStatus = quest.user_status || {};
  const completed = userStatus.completed_at || quest.completed_at;
  const enrolled = userStatus.enrolled_at || quest.enrolled_at || true; // Assume enrolled if in list
  
  return { id, name, appName, appId, questType, duration, completed, enrolled, config };
}

async function completeQuest(quest, message) {
  const info = getQuestInfo(quest);
  const questId = info.id;
  const config = info.config;
  
  // Determine completion method based on quest type
  if (info.questType === 'Watch' || config.video_progress_requirement) {
    // Video/Watch quest
    const duration = config.video_progress_requirement?.duration_seconds || 
                     config.stream_duration_requirement?.duration_seconds || 900;
    
    await message.channel.send(`🎬 Starting watch quest: **${info.name}**\nDuration: ${Math.ceil(duration / 60)} min\nSending progress...`);
    
    // Send video progress in chunks
    const chunkSize = 30;
    const intervals = Math.ceil(duration / chunkSize);
    
    for (let i = 0; i < intervals; i++) {
      const timestamp = Math.min((i + 1) * chunkSize, duration);
      try {
        await axios.post(
          `https://discord.com/api/v9/users/@me/quests/${questId}/video-progress`,
          { timestamp },
          {
            headers: {
              'Authorization': process.env.DISCORD_TOKEN,
              'Content-Type': 'application/json'
            }
          }
        );
      } catch (e) {
        console.error('Video progress error:', e.response?.data || e.message);
      }
      await new Promise(r => setTimeout(r, 500));
    }
    return true;
    
  } else if (info.questType === 'Stream' || config.stream_progress_requirement) {
    // Stream quest - need to simulate streaming
    const duration = config.stream_progress_requirement?.duration_seconds ||
                     config.stream_duration_requirement?.duration_seconds || 900;
    const appId = info.appId;
    
    await message.channel.send(`📺 Starting stream quest: **${info.name}**\nApp: ${info.appName}\nDuration: ${Math.ceil(duration / 60)} min\nSending heartbeats...`);
    
    const intervals = Math.ceil(duration / 30);
    for (let i = 0; i < intervals; i++) {
      try {
        await axios.post(
          `https://discord.com/api/v9/users/@me/quests/${questId}/heartbeat`,
          { stream_key: `call:${client.user.id}:1` },
          {
            headers: {
              'Authorization': process.env.DISCORD_TOKEN,
              'Content-Type': 'application/json'
            }
          }
        );
      } catch (e) {
        console.error('Heartbeat error:', e.response?.data || e.message);
      }
      await new Promise(r => setTimeout(r, 500));
    }
    return true;
    
  } else {
    // Desktop game quest or generic
    const duration = config.play_on_desktop?.duration_seconds || 900;
    
    await message.channel.send(`🎮 Starting game quest: **${info.name}**\nApp: ${info.appName}\nDuration: ${Math.ceil(duration / 60)} min\nSending heartbeats...`);
    
    const intervals = Math.ceil(duration / 30);
    for (let i = 0; i < intervals; i++) {
      try {
        await axios.post(
          `https://discord.com/api/v9/users/@me/quests/${questId}/heartbeat`,
          { stream_key: null },
          {
            headers: {
              'Authorization': process.env.DISCORD_TOKEN,
              'Content-Type': 'application/json'
            }
          }
        );
      } catch (e) {
        console.error('Heartbeat error:', e.response?.data || e.message);
      }
      await new Promise(r => setTimeout(r, 500));
    }
    return true;
  }
}

client.on('messageCreate', async (message) => {
  if (message.author.id !== client.user.id) return;
  const content = message.content.trim();

  // ── quest / quest complete <id> / quest debug ───────────────────────────────
  if (content.toLowerCase() === 'quest' || content.toLowerCase().startsWith('quest ')) {
    const args = content.slice(5).trim().split(/\s+/);
    
    await message.delete().catch(() => {});
    
    // quest debug - show raw API response
    if (args[0]?.toLowerCase() === 'debug') {
      const loadingMsg = await message.channel.send('Fetching raw quest data...');
      const quests = await fetchQuests();
      
      if (quests.length === 0) {
        await loadingMsg.edit('No quests returned from API.');
        return;
      }
      
      // Show first quest structure for debugging
      const debugInfo = JSON.stringify(quests[0], null, 2).slice(0, 1800);
      await loadingMsg.edit(`**Raw Quest Data (first quest):**\n\`\`\`json\n${debugInfo}\n\`\`\``);
      return;
    }
    
    // quest complete <id>
    if (args[0]?.toLowerCase() === 'complete' && args[1]) {
      const questIndex = parseInt(args[1], 10) - 1;
      
      if (cachedQuests.length === 0) {
        await fetchQuests();
      }
      
      if (isNaN(questIndex) || questIndex < 0 || questIndex >= cachedQuests.length) {
        await message.channel.send(`Invalid quest ID. Use \`quest\` to see available quests (${cachedQuests.length} total).`);
        return;
      }
      
      const quest = cachedQuests[questIndex];
      const success = await completeQuest(quest, message);
      
      if (success) {
        const info = getQuestInfo(quest);
        await message.channel.send(`✅ Quest completed: **${info.name}**\nCheck your quest progress in Discord!`);
      }
      return;
    }
    
    // quest (list)
    const loadingMsg = await message.channel.send('Fetching quests...');
    const quests = await fetchQuests();
    
    if (quests.length === 0) {
      await loadingMsg.edit('No quests available. Make sure you have quests in Discord.');
      return;
    }
    
    let response = `**📜 Quests (${quests.length})**\n\n`;
    
    quests.forEach((quest, index) => {
      const info = getQuestInfo(quest);
      const status = info.completed ? '✅ Done' : '⏳ Active';
      const durationStr = info.duration > 0 ? `${Math.ceil(info.duration / 60)} min` : 'N/A';
      
      response += `**${index + 1}.** ${info.name}\n`;
      response += `   📱 ${info.appName} | 🎮 ${info.questType} | ⏱️ ${durationStr}\n`;
      response += `   ${status}\n\n`;
    });
    
    response += `Use \`quest complete <id>\` to complete.\nUse \`quest debug\` to see raw data.`;
    
    await loadingMsg.edit(response);
    return;
  }
});

client.login(process.env.DISCORD_TOKEN);
